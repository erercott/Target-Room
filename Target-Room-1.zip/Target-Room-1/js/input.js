export const input = {
    lastKey: null
};

window.addEventListener("keydown", (e) => {
    let key = e.key.toLowerCase();

    // ignore modifier keys
    if (key === "shift" || key === "control" || key === "alt") return;

    input.lastKey = key;
});