export const aprilDialogue = [

"I love these worlds",

"But",

"the hands",

"that shaped them fade",

"Lost",
 
"beneath the screen"


];