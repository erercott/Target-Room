export const mayDialogue = [

"The answers",
 
"are here",

"Hidden in forgotten words",

"You grow when ready"

];