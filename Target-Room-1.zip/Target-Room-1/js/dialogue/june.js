export const juneDialogue = [

"Every frame a painting",

"Even the broken images",

"Still hold a heartbeat"

];