import { Enemy } from "./enemy.js";

const enemy = new Enemy(200,150);