import { Enemy } from "./enemy.js";
import { input } from "./input.js";
import { aprilDialogue } from "./dialogue/april.js";
import { mayDialogue } from "./dialogue/may.js";
import { juneDialogue } from "./dialogue/june.js";

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");




let currentRoom = "arcade";

let aprilPosition = 0;
let mayPosition = 0;
let junePosition = 0;

let enemy = new Enemy(280, 190);
let score = 0;



canvas.addEventListener("click", (event) => {

    const rect = canvas.getBoundingClientRect();

    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;


    // ARCADE / CAFE
    if (
        mouseX > canvas.width - 120 &&
        mouseY > canvas.height - 50
    ) {

        if (currentRoom === "arcade") {
            currentRoom = "cafe";
        } else if (currentRoom === "cafe") {
            currentRoom = "arcade";
        }

    }


    // CAFE CHARACTERS
    if (currentRoom === "cafe") {

        // APRIL
        if (
            mouseX > 80 &&
            mouseX < 180 &&
            mouseY > 150 &&
            mouseY < 200
        ) {
            currentRoom = "april";
        }


        // MAY
        if (
            mouseX > 80 &&
            mouseX < 180 &&
            mouseY > 190 &&
            mouseY < 240
        ) {
            currentRoom = "may";
        }
			// JUNE 
		if (
			mouseX > 80 && 
			mouseX < 180 && 
			mouseY > 240 && 
			mouseY < 290
		){
			currentRoom = "june";
		}

    }


    // APRIL ROOM BUTTONS
    if (currentRoom === "april") {

        if (
            mouseX > 80 &&
            mouseX < 160 &&
            mouseY > canvas.height - 50 &&
            mouseY < canvas.height
        ) {
            currentRoom = "cafe";
        }


        if (
            mouseX > 240 &&
            mouseX < 330 &&
            mouseY > canvas.height - 50 &&
            mouseY < canvas.height
        ) {
            if (aprilPosition < aprilDialogue.length) {
                aprilPosition++;
            }
        }

    }


    // MAY ROOM BUTTONS
    if (currentRoom === "may") {

        if (
            mouseX > 80 &&
            mouseX < 160 &&
            mouseY > canvas.height - 50 &&
            mouseY < canvas.height
        ) {
            currentRoom = "cafe";
        }


        if (
            mouseX > 240 &&
            mouseX < 330 &&
            mouseY > canvas.height - 50 &&
            mouseY < canvas.height
        ) {
            if (mayPosition < mayDialogue.length) {
                mayPosition++;
            }
        }

    }
	
	// JUNE ROOM BUTTONS
if (currentRoom === "june") {

    // BACK
    if (
        mouseX > 80 &&
        mouseX < 160 &&
        mouseY > canvas.height - 50 &&
        mouseY < canvas.height
    ) {
        currentRoom = "cafe";
    }


    // NEXT
    if (
        mouseX > 240 &&
        mouseX < 330 &&
        mouseY > canvas.height - 50 &&
        mouseY < canvas.height
    ) {
        if (junePosition < juneDialogue.length) {
            junePosition++;
        }
    }

}
	

});

function isEnemyDead(enemy) {
    return enemy.joints.every(j => !j.active);
}


function update() {

    if (input.lastKey) {

        enemy.joints.forEach(j => {

            if (j.active && j.key === input.lastKey) {
                j.active = false;
            }

        });

        input.lastKey = null;
    }


    if (isEnemyDead(enemy)) {

        score++;

        enemy = new Enemy(280, 190);
    }
}



function draw() {

    // clear screen
    ctx.fillStyle = "black";
    ctx.fillRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    // CAFE ROOM
    if (currentRoom === "cafe") {

        ctx.fillStyle = "white";
        ctx.font = "20px monospace";

        ctx.fillText(
            "CAFE",
            280,
            80
        );

        ctx.font = "16px monospace";

        ctx.fillText(
            "April",
            100,
            180
        );

        ctx.fillText(
            "May",
            100,
            220
        );

        ctx.fillText(
            "June",
            100,
            260
        );

        ctx.fillText(
            "[ ARCADE ]",
            canvas.width - 120,
            canvas.height - 20
        );

        return;
    }



    // APRIL ROOM
    if (currentRoom === "april") {

        ctx.fillStyle = "white";
        ctx.font = "20px monospace";

        ctx.fillText(
            "APRIL",
            280,
            80
        );

        ctx.font = "16px monospace";


        if (aprilPosition < aprilDialogue.length) {

            ctx.fillText(
                aprilDialogue[aprilPosition],
                320,
                200
            );

        } else {

            ctx.fillText(
                "[END OF TEXT]",
                100,
                200
            );

        }


        ctx.fillText(
            "[BACK]",
            100,
            canvas.height - 20
        );


        ctx.fillText(
            "[NEXT]",
            250,
            canvas.height - 20
        );

        return;
    }



    // MAY ROOM
    if (currentRoom === "may") {

        ctx.fillStyle = "white";
        ctx.font = "20px monospace";

        ctx.fillText(
            "MAY",
            280,
            80
        );


        ctx.font = "16px monospace";


        if (mayPosition < mayDialogue.length) {

            ctx.fillText(
                mayDialogue[mayPosition],
                320,
                200
            );

        } else {

            ctx.fillText(
                "[END OF TEXT]",
                100,
                200
            );

        }


        ctx.fillText(
            "[BACK]",
            100,
            canvas.height - 20
        );


        ctx.fillText(
            "[NEXT]",
            250,
            canvas.height - 20
        );
		


        return;
    }
	// JUNE ROOM
if (currentRoom === "june") {

    ctx.fillStyle = "white";
    ctx.font = "20px monospace";

    ctx.fillText(
        "JUNE",
        280,
        80
    );

    ctx.font = "14px monospace";

    if (junePosition < juneDialogue.length) {

        ctx.fillText(
            juneDialogue[junePosition],
            320,
			200
        );

    } else {

        ctx.fillText(
            "[END OF TEXT]",
            100,
            200
        );

    }

    ctx.fillText(
        "[BACK]",
        100,
        canvas.height - 20
    );

    ctx.fillText(
        "[NEXT]",
        250,
        canvas.height - 20
    );

    return;
}



    // ARCADE ROOM

    ctx.strokeStyle = "white";
    ctx.lineWidth = 2;

    ctx.strokeRect(
        10,
        10,
        canvas.width - 20,
        canvas.height - 20
    );


    ctx.fillStyle = "white";
    ctx.font = "16px monospace";
	ctx.textAlign = "center";



    ctx.fillText(
        "TARGET ROOM",
        canvas.width /2, 
        35
    );


    ctx.fillText(
        "SCORE: " + score,
        canvas.width / 2, 
        canvas.height - 20
    );


    ctx.fillText(
        "SYSTEM: ONLINE",
        canvas.width / 2, 
        55
    );

ctx.textAlign = "left";

    ctx.fillText(
        "[CAFE]",
        canvas.width - 100,
        canvas.height - 20
    );


    enemy.draw(ctx);

}



function loop() {

    update();
    draw();

    requestAnimationFrame(loop);
}


loop();