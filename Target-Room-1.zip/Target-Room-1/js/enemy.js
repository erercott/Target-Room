export class Enemy {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 80;

        const keyPool = [
            "1","2","3","4","5","6","7","8","9","0",
            "q","w","e","r","t","y","u","i","o","p",
            "a","s","d","f","g","h","j","k","l",
            "z","x","c","v","b","n","m"
        ];

        const shuffled = [...keyPool].sort(() => Math.random() - 0.5);

        this.joints = shuffled.slice(0, 4).map(key => ({
            key,
            active: true
        }));
    }

    draw(ctx) {

      const points = [
    { x: this.x + 40, y: this.y, index: 0 },
    { x: this.x, y: this.y + 40, index: 1 },
    { x: this.x + 80, y: this.y + 40, index: 2 },
    { x: this.x + 40, y: this.y + 80, index: 3 }
];

        ctx.font = "14px monospace";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";

        points.forEach(p => {
            const j = this.joints[p.index];

            if (!j.active) return;

            const w = 28;
            const h = 22;

            ctx.strokeStyle = "white";
            ctx.strokeRect(
                p.x - w / 2,
                p.y - h / 2,
                w,
                h
            );

            ctx.fillStyle = "white";
            ctx.fillText(
                j.key,
                p.x,
                p.y
            );
        });
    }
}